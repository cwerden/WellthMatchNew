export default function Home() {
  return (
    <div style={{ padding: "4rem", textAlign: "center" }}>
      <h1 style={{ fontSize: "2rem", color: "#2eb97f" }}>
        ✅ WellthMatch is Live!
      </h1>
      <p style={{ marginTop: "1rem" }}>
        This is your homepage. The financial advisor matching quiz will go here.
      </p>
    </div>
  );
}