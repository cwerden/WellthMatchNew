# WellthMatch.com

This is a custom-built financial advisor matching quiz app. Deploy it on Vercel:

1. Visit https://vercel.com/import
2. Upload this ZIP file
3. Click 'Deploy' — you're live!
